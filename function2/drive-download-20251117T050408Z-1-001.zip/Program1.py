def introduce(name, age, profession):
    print("Name:", name)
    print("Age:", age)
    print("Profession:", profession)

introduce(name="Suyash", age=20, profession="Teacher")
