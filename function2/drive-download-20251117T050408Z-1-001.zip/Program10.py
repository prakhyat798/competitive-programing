def fun1():
    name = "Harshita"

    def fun2():
        name = "Gupta"

    fun2()
    print(name)

fun1()
