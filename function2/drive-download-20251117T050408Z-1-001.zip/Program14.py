Max = lambda a, b: a if a > b else b
print(Max(1, 2))
