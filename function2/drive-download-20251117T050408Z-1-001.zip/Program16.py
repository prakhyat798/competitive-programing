arr = [10, 21, 32, 43, 55, 60]
ans = list(filter(lambda x: x % 2 == 0, arr))
print(ans)
