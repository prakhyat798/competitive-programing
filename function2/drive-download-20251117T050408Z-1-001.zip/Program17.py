arr = [1, 2, 3, 4]
ans = list(map(lambda x: x + 10, arr))
print(ans)
