names = ["HARSHITA", "GUPTA"]
result = list(map(lambda x: x.lower(), names))
print(result)
