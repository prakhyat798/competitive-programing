def introduce(name, age, profession="Student"):
    print("Name:", name)
    print("Age:", age)
    print("Profession:", profession)

introduce("Suyash", 20)
introduce("Harshita", 22, "Developer")
