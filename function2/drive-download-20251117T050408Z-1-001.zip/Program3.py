def square(x):
    return x * x

def pythagoras(a, b):
    return square(a) + square(b)

c2 = pythagoras(3, 4)
print("c2 =", c2)
