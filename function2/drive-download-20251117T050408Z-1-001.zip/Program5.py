name = "Harshita"

def test():
    print(name)
    lang = "Python"
    print(lang)

test()
print(name)
