def test():
    lang = "Python"
    print(lang)

test()
# print(lang)  # remove or define globally
