name = "Harshita"
print(name)

def test():
    global name
    print(name)
    name = "Gupta"
    print(name)

test()
print(name)
